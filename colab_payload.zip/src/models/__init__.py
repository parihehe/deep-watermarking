"""Learned decoder architectures."""
